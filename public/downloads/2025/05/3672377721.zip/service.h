#pragma once

#include <string>
#include <atomic>

#include "BlockingQueue.h"
#include "Log.h"

std::atomic<bool> exit_requested(false);
BlockingQueue<std::string> m_queueMsg;
Log service_log;

const short DEFAULT_LOG_LOGLEVEL = LEVEL_VERBOSE;
const short DEFAULT_LOG_PRINTLEVEL = LEVEL_VERBOSE;