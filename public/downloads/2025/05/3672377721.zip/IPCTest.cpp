﻿// IPCTest.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "service.h"
#ifdef _WIN32
#include "service-windows.h"
#elif defined(__linux__)
#include "service-linux.h"
#endif

int main(int argc, const char* args[]) {
	if (std::string(args[1]) != "serve") {
		send_message(args[1]);
		service_log.push(LEVEL_INFO, "Message sent: %s", args[1]);
		return 0;
	}
	
	register_service();

	service_log.push(LEVEL_INFO, "IPC Receive ready.");

	while (!exit_requested.load()) {
		std::string msg = m_queueMsg.take();
		service_log.push(LEVEL_INFO, "Receive msg: %s", msg.c_str());
		if(msg=="exit")exit_requested.store(true);
	}

	clean_service();

	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
